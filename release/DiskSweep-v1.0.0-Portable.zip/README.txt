# DiskSweep

A high-performance, dark-themed storage capacity analyzer and system cleanup utility for Windows, styled in the classic, utilitarian aesthetic of Sysinternals RAMMap and WinDirStat.

![Platform](https://img.shields.io/badge/platform-Windows%2010%20%7C%2011-007acc)
![Framework](https://img.shields.io/badge/framework-.NET%2010%20WPF-512bd4)
![License](https://img.shields.io/badge/license-MIT-green)

---

## Features

### 1. Real-Time Storage Capacity & Drive Health
- Live monitoring across all local, removable, and fixed storage drives.
- Visual health meters color-coded by capacity threshold (Healthy Green > 20%, Warning Amber 10–20%, Critical Red < 10%).
- Detailed breakdown: Total capacity, used space, free space, exact percentage, filesystem (NTFS, FAT32, exFAT), and volume labels.
- Instant right-click context menu to explore drives or launch Windows Disk Management / Storage Sense.

### 2. Comprehensive Deep Clean Engine
Identifies safe, regenerable temporary and cache files across Windows and user applications:
- **System Temporary Files**: `%TEMP%`, Windows System Temp (`C:\Windows\Temp`), Prefetch traces.
- **Windows Updates & Diagnostics**: Downloaded installation cache (`SoftwareDistribution\Download`), Windows Error Reporting (WER) logs, and user/kernel crash minidumps.
- **Graphics & Shader Caches**: DirectX 11/12 shader caches (`D3DSCache`), NVIDIA DXCache/GLCache, and AMD Radeon shader caches.
- **Browser Caches**: Clean cache data for Google Chrome, Microsoft Edge, Brave, Mozilla Firefox, Opera, and Opera GX (preserves logins, passwords, cookies, and history).
- **Application & Gaming Caches**: Discord media/code cache, Steam web CEF cache, Spotify offline stream storage.
- **Developer Package Caches**: Python Pip wheels, Node.js NPM tarballs, Rust Cargo caches.
- **Windows Recycle Bin**: Granular control over the Windows Recycle Bin with one-click purge via Win32 Shell APIs.

### 3. Granular Selection & Resilient Deletion
- **Pick and Choose**: Master category checkboxes with tri-state toggles or granular file-group selection.
- **Safety Ratings**: Every item is flagged with a safety level (`SAFE`, `NORMAL`, `CAUTION`) with live descriptions explaining what the files are and why they can be cleared.
- **Non-Destructive Deletion**: Handles locked and in-use files gracefully — skips active files without crashing, throwing unhandled exceptions, or aborting the sweep.
- **Space Analyzer (Large Files)**: Integrated scanner to quickly identify the top 100 space hogs (>50 MB) on any drive, with direct options to explore or recycle.
- **Live Audit Log**: Monospace activity console recording every operation, deleted count, locked items skipped, and exact bytes reclaimed.

---

## Requirements & Running

- **OS**: Windows 10 (1809+) or Windows 11 (x64)
- **Runtime**: [.NET 10 Desktop Runtime](https://dotnet.microsoft.com/download)

### Run Immediately
Double-click `run.bat` or run:
```cmd
.\bin\Release\net10.0-windows\DiskSweep.exe
```

### Build from Source
```cmd
dotnet build -c Release
```

---

## Keyboard Shortcuts

| Shortcut | Action |
|---|---|
| `F5` | Scan System cleanable targets |
| `Ctrl + R` | Refresh drive statistics |
| `Ctrl + A` | Select all items |
| `Esc` | Cancel running scan or cleanup |
| `F1` | About DiskSweep |

---

## Architecture & Safety Guarantees

- **Asynchronous Execution**: All disk scanning and deletion runs on background worker threads via `Task.Run` and cancellation tokens, keeping the UI completely responsive at 60 FPS.
- **Zero-Harm Design**: Only cleans contents of temporary directories, never deleting root system or environment folders.
- **Win32 Shell Integration**: Native dark titlebar through `DwmSetWindowAttribute`, shell Recycle Bin management through `shell32.dll`.
